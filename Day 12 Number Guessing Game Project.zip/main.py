#Number Guessing Game 

from random import randint
from art import logo 


easy_level=10
hard_level=5

def choose_level():
  level=input("Choose a difficulty. Type 'easy' or 'hard':"
  )
  if level=="easy":
    choose=easy_level
    return easy_level
  else:
    choose=hard_level
    return hard_level

def check_guess(guess,answer,choose):
    if guess>answer:
      print("Too hight.")
      return choose - 1 
    elif guess<answer:
      print("Too low.")
      return choose-1
    else:
      print(f"You got it, the answer was {answer}.")

def game():   
  print(logo)
  print("Welcome to the number guessing game :)")
  print("I'm thinking of a number between 1 and 100")

  answer= randint(1,100)
  #print(f"Psst, the correct answer is {answer}")
  choose=choose_level()

  guess=0
  while guess!=answer:
    print(f"You have {choose} attemps remaining to guess the number.")
    guess = int(input("Make a guess: "))
    choose=check_guess(guess,answer,choose)
    if choose==0:
      print("You've run out of guesses, You lose!")
      return
    elif guess!=answer:
      print("Guess again.")

game()

