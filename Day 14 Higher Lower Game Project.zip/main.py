#import logo , data, random 
from art import logo, vs
import random 
from game_data import data 
print(logo)
score=0
should_continue=True

#Format data 
def datas(account):
  account_name=account["name"]
  account_description=account["description"]
  account_country=account["country"]
  return f"{account_name}, a {account_description} from {account_country}"

#account comparison and checking
def check(guess, a_fallower, b_fallower):
  if a_fallower>b_fallower:
    return guess=="a"
  elif b_fallower>a_fallower:
    return guess=="b"

#continuity of the game
while should_continue:

#random data selection

  a = random.choice(data)
  b = random.choice(data)
  if a==b:
    b=random.choice(data)

  print(f"Compare A: {datas(a)}")
  print(vs)
  print(f"Against B: {datas(b)}")

  #Ask player guess 
  guess=input ("Who was more followers ? Type 'A or 'B : ").lower()
  #get fallower count each account 
  a_fallower= a["follower_count"]
  b_fallower= b["follower_count"]

  truth = check(guess,a_fallower,b_fallower)

  if truth:
    score+=1
    print(f"You're right! Current score: {score}")
  else:
    should_continue = False 
    print(f"Sorry, that's wrong. Game over! Final score:{score}")